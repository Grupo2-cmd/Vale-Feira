# Adicionar esta linha na classe Config:
CHAT_ENCRYPTION_KEY = os.environ.get('CHAT_ENCRYPTION_KEY') or 'vale_feira_default_key_2025'
